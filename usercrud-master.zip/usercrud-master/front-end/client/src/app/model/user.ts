export class User {

    id: string;
    name: string;
    surname: string;
    address: string;
    city: string;

    constructor(){
        this.id="";
        this.name="";
        this.surname="";
        this.address="";
        this.city="";

    }
}
